# OUTPUT SCREEN:
![Screenshot (57)](https://github.com/puspalata121/PRODIGY_FS_01/blob/main/Screenshot%20(57).png)

![Screenshot (58)](https://github.com/puspalata121/PRODIGY_FS_01/blob/main/Screenshot%20(58).png)

#Frontend:

HTML for structuring the web pages.

CSS for styling and layout.

JavaScript for client-side interactivity and validation.

#Backend:

PHP for server-side logic and handling requests.

MySQL for storing user data and session information.

# Features:
This is a user authentication application
* Session activity like logged in / logged out are recorded
* Authentication 


